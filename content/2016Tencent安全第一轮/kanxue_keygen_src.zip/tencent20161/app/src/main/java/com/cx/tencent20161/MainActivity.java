package com.cx.tencent20161;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.cx.tencent20161.utils.KeyGen;


public class MainActivity extends Activity implements View.OnClickListener {

    private EditText mName = null;
    private TextView mCode = null;
    private Button mBtn = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mName = (EditText) findViewById(R.id.id_name);
        mCode = (TextView) findViewById(R.id.id_code);
        mBtn = (Button) findViewById(R.id.id_btn);

        mBtn.setOnClickListener(this);



    }

    @Override
    public void onClick(View v) {
        KeyGen keygen = null;
        try {
            keygen = new KeyGen(mName.getText().toString());
        } catch (Exception e) {
            Toast.makeText(MainActivity.this, "name len: 6~20", Toast.LENGTH_LONG).show();
            return;
        }

        keygen.nameProc();
        mCode.setText(keygen.getCode());
    }
}
